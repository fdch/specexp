# ./fd_bufvid part of fd_lib .
