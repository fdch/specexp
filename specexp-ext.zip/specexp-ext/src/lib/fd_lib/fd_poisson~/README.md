# fd_poisson~ 
part of fd_lib

