# fd_getsize 
part of fd_lib

