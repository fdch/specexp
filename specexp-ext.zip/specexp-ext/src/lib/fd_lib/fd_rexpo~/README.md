# fd_rexpo~ 
part of fd_lib

