# fd_hopmsec 
part of fd_lib

