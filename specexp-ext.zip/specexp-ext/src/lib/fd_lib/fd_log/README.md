# fd_log 
part of fd_lib

