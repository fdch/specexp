# fd_triangle~ 
part of fd_lib

