# fd_z12 
part of fd_lib

