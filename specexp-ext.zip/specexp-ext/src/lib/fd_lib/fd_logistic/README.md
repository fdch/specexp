# fd_logistic 
part of fd_lib

