# fd_minimax 
part of fd_lib

