# fd_gemsphere 
part of fd_lib

