# fd_delit 
part of fd_lib

