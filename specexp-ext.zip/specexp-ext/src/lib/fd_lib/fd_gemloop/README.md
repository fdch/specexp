# ./fd_gemloop part of fd_lib .
