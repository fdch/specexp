# fd_dataRead1 
part of fd_lib

