# fd_tovowel 
part of fd_lib

