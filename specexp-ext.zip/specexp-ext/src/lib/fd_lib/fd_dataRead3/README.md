# fd_dataRead3 
part of fd_lib

