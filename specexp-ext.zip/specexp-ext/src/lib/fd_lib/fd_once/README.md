# fd_once 
part of fd_lib

