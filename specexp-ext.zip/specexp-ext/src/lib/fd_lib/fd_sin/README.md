# fd_sin 
part of fd_lib

