# fd_iterate 
part of fd_lib

