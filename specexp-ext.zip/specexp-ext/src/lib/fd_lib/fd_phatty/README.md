# fd_phatty 
part of fd_lib

