# fd_input 
part of fd_lib

