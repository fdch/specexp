# fd_relocate 
part of fd_lib

