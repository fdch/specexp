# fd_msecparse 
part of fd_lib

