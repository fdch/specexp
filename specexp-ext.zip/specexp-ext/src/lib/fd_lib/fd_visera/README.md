# fd_visera 
part of fd_lib

