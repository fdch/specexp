# fd_GEMbuffsize 
part of fd_lib

