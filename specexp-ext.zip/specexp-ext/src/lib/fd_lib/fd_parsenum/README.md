# fd_parsenum 
part of fd_lib

