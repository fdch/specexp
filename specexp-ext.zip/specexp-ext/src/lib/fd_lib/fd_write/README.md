# fd_write
Run from terminal
	$ ./run full/path filename length-in-minutes

