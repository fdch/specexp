# fd_markov3 
part of fd_lib

