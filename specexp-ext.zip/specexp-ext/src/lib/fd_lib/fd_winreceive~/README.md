# fd_hann0 
part of fd_lib

