# fd_cauchy~ 
part of fd_lib

