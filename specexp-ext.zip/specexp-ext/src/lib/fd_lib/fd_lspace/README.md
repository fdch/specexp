# fd_lspace 
part of fd_lib

