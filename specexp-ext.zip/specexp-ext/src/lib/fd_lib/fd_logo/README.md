# fd_logo 
part of fd_lib

