# fd_exp 
part of fd_lib

