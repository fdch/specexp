# fd_n! 
part of fd_lib

