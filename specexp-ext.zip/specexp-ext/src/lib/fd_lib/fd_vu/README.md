# fd_vu 
part of fd_lib

