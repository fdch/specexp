# fd_rec 
part of fd_lib

