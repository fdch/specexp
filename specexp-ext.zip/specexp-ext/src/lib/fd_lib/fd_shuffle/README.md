# fd_shuffle 
part of fd_lib

