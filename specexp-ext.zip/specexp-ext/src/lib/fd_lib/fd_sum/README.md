# fd_sum 
part of fd_lib

