# fd_mult 
part of fd_lib

