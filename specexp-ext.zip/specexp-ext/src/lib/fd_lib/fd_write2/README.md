# fd_write2 
part of fd_lib

