# fd_dataMorphWidth 
part of fd_lib

