# fd_gauss 
part of fd_lib

