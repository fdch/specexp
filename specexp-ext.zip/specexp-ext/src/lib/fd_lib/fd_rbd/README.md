# fd_random-bar-distribution 
part of fd_lib

