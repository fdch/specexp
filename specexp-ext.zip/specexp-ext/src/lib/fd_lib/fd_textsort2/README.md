# fd_textsort2 
part of fd_lib

