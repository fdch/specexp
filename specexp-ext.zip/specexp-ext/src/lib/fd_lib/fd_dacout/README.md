# fd_dacout 
part of fd_lib

