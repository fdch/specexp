# fd_rgbcol 
part of fd_lib

