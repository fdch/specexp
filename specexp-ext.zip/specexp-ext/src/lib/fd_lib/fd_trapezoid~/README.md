# fd_trapezoid~ 
part of fd_lib

