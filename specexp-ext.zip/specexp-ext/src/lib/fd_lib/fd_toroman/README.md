# fd_toroman 
part of fd_lib

