# fd_lorsig 
part of fd_lib

