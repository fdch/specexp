# fd_kinetica 
part of fd_lib

