# ./fd_vidbuf part of fd_lib .
