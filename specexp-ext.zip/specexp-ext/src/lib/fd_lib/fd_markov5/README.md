# fd_markov-5 
part of fd_lib

