# fd_objcreator 
part of fd_lib

