# fd_s-prob 
part of fd_lib

