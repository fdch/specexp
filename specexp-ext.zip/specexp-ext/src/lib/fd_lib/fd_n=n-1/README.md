# fd_n=n-1 
part of fd_lib

