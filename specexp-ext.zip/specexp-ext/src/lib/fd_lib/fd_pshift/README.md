# fd_pshift 
part of fd_lib

