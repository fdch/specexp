# fd_siginfo 
part of fd_lib

