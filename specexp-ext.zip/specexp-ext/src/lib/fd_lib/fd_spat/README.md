# fd_spat 
part of fd_lib

