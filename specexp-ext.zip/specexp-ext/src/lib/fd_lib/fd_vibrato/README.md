# fd_vibrato 
part of fd_lib

