# fd_shift 
part of fd_lib

