# fd_getid 
part of fd_lib

