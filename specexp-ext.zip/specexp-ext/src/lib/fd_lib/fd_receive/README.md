# fd_receive 
part of fd_lib

