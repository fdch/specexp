# fd_write1 
part of fd_lib

