# ./fd_emap2 part of fd_lib .
