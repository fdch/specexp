# fd_gr 
part of fd_lib

