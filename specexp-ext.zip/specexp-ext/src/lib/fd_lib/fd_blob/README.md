# ./fd_blob part of fd_lib .
