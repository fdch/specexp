# fd_cubic 
part of fd_lib

