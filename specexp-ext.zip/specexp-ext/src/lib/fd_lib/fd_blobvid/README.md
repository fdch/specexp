# ./fd_blobvid part of fd_lib .
