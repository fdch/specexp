# fd_dataRead 
part of fd_lib

