# fd_salvo 
part of fd_lib

