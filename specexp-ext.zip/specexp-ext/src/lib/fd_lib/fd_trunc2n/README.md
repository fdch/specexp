# ./fd_trunc2n part of fd_lib .
