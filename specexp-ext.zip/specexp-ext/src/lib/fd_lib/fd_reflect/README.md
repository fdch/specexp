# fd_reflect 
part of fd_lib

