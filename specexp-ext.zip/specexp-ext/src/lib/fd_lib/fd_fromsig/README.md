# ./fd_fromsig part of fd_lib .
