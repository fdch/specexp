# fd_wielevy2 
part of fd_lib

