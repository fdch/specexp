# fd_spigot3 
part of fd_lib

