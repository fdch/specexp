# fd_osc 
part of fd_lib

