# fd_spline~ 
part of fd_lib

