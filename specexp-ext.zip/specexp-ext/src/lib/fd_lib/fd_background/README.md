# ./fd_background part of fd_lib .
