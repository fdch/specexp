# fd_norm-abs 
part of fd_lib

