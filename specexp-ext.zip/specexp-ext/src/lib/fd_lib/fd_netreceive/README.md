# fd_netreceive 
part of fd_lib

