# fd_mtxdelit 
part of fd_lib

