# fd_critical 
part of fd_lib

