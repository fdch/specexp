# fd_arcsin~ 
part of fd_lib

