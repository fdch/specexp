# fd_dataDroplet 
part of fd_lib

