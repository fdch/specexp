# fd_next 
part of fd_lib

