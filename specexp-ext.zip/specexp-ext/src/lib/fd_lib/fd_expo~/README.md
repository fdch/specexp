# fd_expo~ 
part of fd_lib

