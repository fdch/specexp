# fd_dataRand 
part of fd_lib

