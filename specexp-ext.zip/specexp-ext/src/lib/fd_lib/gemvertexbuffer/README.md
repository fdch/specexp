# gemvertexbuffer
I included this external here but i am not its author. I do not claim authorship of this, i simply included it to make some helpfiles work. The current Gem version is older than this external, and therefore the 'gemvertexbuffer' is not included in it. gemvertexbuffer author is Cyrille Henry.

