# fd_s-prob-5 
part of fd_lib

