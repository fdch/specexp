# fd_sinc~ 
part of fd_lib

