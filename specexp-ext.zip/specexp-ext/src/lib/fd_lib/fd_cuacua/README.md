# fd_cuacua 
part of fd_lib

