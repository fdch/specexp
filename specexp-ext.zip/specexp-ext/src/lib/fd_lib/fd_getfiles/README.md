# fd_getfiles 
part of fd_lib

