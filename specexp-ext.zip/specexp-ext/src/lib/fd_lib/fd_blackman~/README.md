# fd_blackman~ 
part of fd_lib

