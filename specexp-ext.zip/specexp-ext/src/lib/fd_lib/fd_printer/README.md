# fd_printer 
part of fd_lib

