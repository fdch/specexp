# fd_mtxout 
part of fd_lib

