# fd_etareti 
part of fd_lib

