# fd_t-read 
part of fd_lib

