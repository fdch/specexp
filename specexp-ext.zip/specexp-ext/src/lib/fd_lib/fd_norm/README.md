# fd_norm 
part of fd_lib

