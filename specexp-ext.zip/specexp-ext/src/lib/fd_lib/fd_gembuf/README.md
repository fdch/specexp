# ./fd_gembuf part of fd_lib .
