# fd_miller-gauss 
part of fd_lib

