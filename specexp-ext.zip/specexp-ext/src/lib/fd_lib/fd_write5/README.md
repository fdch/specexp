# fd_write5 
part of fd_lib

