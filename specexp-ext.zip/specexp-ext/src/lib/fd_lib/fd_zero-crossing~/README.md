# fd_zero-crossing~ 
part of fd_lib

