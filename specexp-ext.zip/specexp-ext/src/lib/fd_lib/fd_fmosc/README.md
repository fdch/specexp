# fd_fmosc 
part of fd_lib

