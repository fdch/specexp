# fd_untext 
part of fd_lib

