# fd_r 
part of fd_lib

