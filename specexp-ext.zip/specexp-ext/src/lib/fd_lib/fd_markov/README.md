# fd_markov 
part of fd_lib

