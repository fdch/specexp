# fd_spigot 
part of fd_lib

