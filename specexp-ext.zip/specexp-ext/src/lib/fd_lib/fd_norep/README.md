# fd_norep 
part of fd_lib

