# fd_geometric-mean 
part of fd_lib

